/**
 * TrashFlow — Sistema de Monitoreo de Residuos Urbano
 * 
 * Archivo: alertas.js
 * Descripción: Controla la tabla de alertas de residuos, incluyendo los filtros dinámicos por zona, estado
 *              y fecha, la paginación de resultados, la asignación de operarios y la visualización de evidencias.
 * 
 * Dependencias:
 *   - config.js (Usa requestAPI y BASE_URL)
 * 
 * Expone:
 *   - loadAlertas(): Realiza la petición HTTP filtrada y renderiza la tabla.
 */

// Variables globales para controlar la paginación del listado
let currentPage = 1;
const perPage = 10;

// urlParams al scope de módulo: necesaria en loadAlertas() y callbacks de fila
let urlParams = new URLSearchParams(window.location.search);

// Inicialización de escuchadores tras cargar el DOM
document.addEventListener('DOMContentLoaded', () => {
  const token = localStorage.getItem('trashflow_token');
  if (!token) return; // Si no hay token, el flujo es interceptado por auth.js

  initAlertsPage();
});

/**
 * Vincula los formularios de filtros e inicializa los modales de asignación.
 */
async function initAlertsPage() {
  // urlParams ya está declarada al nivel de módulo (scope global del archivo)
  const camaraId = urlParams.get('camara_id');

  if (camaraId) {
    // Persist camara_id in the hidden form field so it survives filter submissions
    const hiddenCamaraId = document.getElementById('filter-camara-id');
    if (hiddenCamaraId) hiddenCamaraId.value = camaraId;

    try {
      const camara = await requestAPI(`/api/camaras/${camaraId}`);
      if (camara) {
        // --- Show context banner with camera name ---
        const banner         = document.getElementById('camara-context-banner');
        const nameEl         = document.getElementById('camara-context-name');
        const topbarTitle    = document.getElementById('topbar-title');
        const topbarSubtitle = document.getElementById('topbar-subtitle');

        if (banner)          banner.classList.remove('hidden');
        if (nameEl)          nameEl.textContent = `${camara.nombre}  •  ${camara.ubicacion}`;
        if (topbarTitle)     topbarTitle.textContent = 'Alertas por Cámara';
        if (topbarSubtitle)  topbarSubtitle.textContent = `📷 ${camara.nombre}`;

        // ⚠️  NO pre-seleccionamos zona: la API filtra directo por camara_id.
        //     Si se pre-selecciona zona, otras cámaras de la misma zona aparecerían.
      }
    } catch (err) {
      console.error('Error al cargar detalle de cámara:', err);
    }
  }

  loadAlertas();
  initAsignarModal();

  // Al enviar el formulario de filtros: mantener camara_id en el campo oculto
  const filterForm = document.getElementById('filters-form');
  if (filterForm) {
    filterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      window.filterFormSubmitted = true;
      window.history.replaceState({}, document.title, window.location.pathname);
      currentPage = 1;
      loadAlertas();
    });
  }

  // Auto-refresco de alertas cada 30 segundos (evita recargar si un modal está interactivo)
  setInterval(() => {
    const modalAsignar = document.getElementById('asignar-operador-modal');
    const modalFoto    = document.getElementById('photo-modal');
    const modalAbierto = (modalAsignar && modalAsignar.classList.contains('active')) ||
                         (modalFoto && modalFoto.classList.contains('active'));
    if (!modalAbierto) {
      loadAlertas();
    }
  }, 30000);
}


/**
 * Consulta las alertas en el backend de Flask aplicando los filtros de la interfaz
 * y dibuja las filas de la tabla de alertas de forma dinámica.
 */
async function loadAlertas() {
  const tableBody = document.querySelector('#alerts-table tbody');
  const paginationInfo = document.getElementById('pagination-info');
  const paginationControls = document.getElementById('pagination-controls');
  
  if (!tableBody) return;

  // Renderiza shimmers de carga en la tabla mientras se completa la llamada de red
  renderTableSkeletons();

  // Obtiene los valores ingresados por el usuario en el panel de filtros
  const q      = document.getElementById('search-input')?.value.trim() || '';
  const zona   = document.getElementById('filter-zona')?.value   || 'Todas las Zonas';
  const estado = document.getElementById('filter-estado')?.value || 'Todos los Estados';
  const fecha  = document.getElementById('filter-fecha')?.value  || '';

  // Determinar si hay un filtro de cámara activo
  const hiddenCamaraId = document.getElementById('filter-camara-id')?.value;
  const urlCamaraId    = new URLSearchParams(window.location.search).get('camara_id');
  const activeCamaraId = hiddenCamaraId || (!window.filterFormSubmitted ? urlCamaraId : null);

  try {
    // Configura los parámetros HTTP.
    // Cuando hay camara_id activo, NO mandamos zona: la API filtra directo por cámara.
    // Si se mandara zona, traería alertas de otras cámaras de la misma zona.
    const queryParams = new URLSearchParams({
      page:     currentPage,
      per_page: perPage,
      q:        q,
      estado:   estado,
      fecha:    fecha,
      ...(activeCamaraId ? {} : { zona: zona })   // zona solo si NO hay filtro de cámara
    });

    if (activeCamaraId) {
      queryParams.set('camara_id', activeCamaraId);
    }

    const alertaId = new URLSearchParams(window.location.search).get('alerta_id');
    if (alertaId && !window.filterFormSubmitted) {
      queryParams.set('alerta_id', alertaId);
    }

    // Realiza la petición GET al backend de Flask
    let data = await requestAPI(`/api/alertas?${queryParams.toString()}`);


    // Si buscamos por alerta_id y no se encontró nada, hacemos fallback a la lista normal
    const queryAlertaId = urlParams.get('alerta_id');
    if (queryAlertaId && (!data.alertas || data.alertas.length === 0)) {
      console.warn(`Alerta con ID ${queryAlertaId} no encontrada. Reestableciendo listado.`);
      queryParams.delete('alerta_id');
      window.history.replaceState({}, document.title, window.location.pathname);
      data = await requestAPI(`/api/alertas?${queryParams.toString()}`);
    }

    // Limpia las animaciones de carga
    tableBody.innerHTML = '';

    // Filtrar alertas descartadas para que no se muestren en la tabla
    data.alertas = (data.alertas || []).filter(a => a.estado !== 'descartada');

    // Maneja el caso de resultados vacíos tras filtrar
    if (data.alertas.length === 0) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="6" class="text-center" style="padding: var(--spacing-xl); color: var(--color-text-secondary);">
            No se encontraron alertas con los filtros especificados.
          </td>
        </tr>
      `;
      if (paginationInfo) paginationInfo.textContent = 'Mostrando 0-0 de 0 alertas';
      if (paginationControls) paginationControls.innerHTML = '';
      return;
    }

    // Mapeo estético de los nombres de estados operativos
    const statesMap = {
      pendiente: { label: 'Pendiente', badgeClass: 'badge-pendiente' },
      asignada: { label: 'Alertada', badgeClass: 'badge-alertada' },
      en_proceso: { label: 'Alertada', badgeClass: 'badge-alertada' },
      alertada: { label: 'Alertada', badgeClass: 'badge-alertada' },
      resuelta: { label: 'Resuelta', badgeClass: 'badge-resuelta' }
    };

    const thirtyMinMs = 30 * 60 * 1000;
    const nowMs = Date.now();

    // Renderiza cada fila de alerta
    data.alertas.forEach(alert => {
      let stateObj = statesMap[alert.estado] || { label: alert.estado, badgeClass: 'badge-alertada' };
      const formattedDate = formatDateTime(alert.fecha);
      const operatorHtml = getOperatorDisplay(alert.operador, alert.id, alert.estado);

      // Comprobación de ventana de 30 minutos de suspensión de cámara
      let alertTime = 0;
      if (alert.fecha) {
        let fStr = String(alert.fecha).trim();
        if (!fStr.endsWith('Z') && !/[+-]\d{2}:?\d{2}$/.test(fStr)) {
          fStr = fStr.replace(' ', 'T') + 'Z';
        }
        alertTime = new Date(fStr).getTime();
      }
      const diffMs = alertTime ? (nowMs - alertTime) : 0;
      let suspensionHtml = '';

      if (alert.estado === 'resuelta') {
        stateObj = { label: 'Resuelta', badgeClass: 'badge-resuelta' };
      } else if (alert.estado !== 'descartada') {
        if (diffMs >= thirtyMinMs) {
          // Ya transcurrieron los 30 minutos sin re-detección: aparece resuelta
          stateObj = { label: 'Resuelta', badgeClass: 'badge-resuelta' };
          suspensionHtml = `
            <div style="font-size: 11px; color: var(--color-success, #2ECC71); margin-top: 4px; display: flex; align-items: center; gap: 4px;">
              <span>✓ Auto-resuelta (30m)</span>
            </div>
          `;
        } else {
          // Dentro de los 30 minutos de suspensión de la cámara
          const remainingSecs = Math.max(0, Math.floor((thirtyMinMs - diffMs) / 1000));
          const remMins = Math.floor(remainingSecs / 60);
          const remSecs = remainingSecs % 60;
          const countdownTarget = alertTime + thirtyMinMs;
          suspensionHtml = `
            <div class="alerta-suspension-box" data-target="${countdownTarget}" data-id="${alert.id}" style="font-size: 11px; color: #F5A623; margin-top: 4px; display: flex; align-items: center; gap: 4px;">
              <span class="cooldown-dot" style="width: 5px; height: 5px; background: #F5A623; border-radius: 50%; display: inline-block;"></span>
              <span>Suspensión: <b class="alerta-countdown-digits">${String(remMins).padStart(2, '0')}:${String(remSecs).padStart(2, '0')}</b></span>
            </div>
          `;
        }
      }

      const row = document.createElement('tr');
      
      // Resaltar y scrollear a la fila si viene el parámetro de alerta única
      const queryAlertaId = urlParams.get('alerta_id');
      if (queryAlertaId && (String(alert.id) === String(queryAlertaId) || String(alert.id).replace(/\D/g, '') === String(queryAlertaId).replace(/\D/g, ''))) {
        row.classList.add('highlighted-row');
        setTimeout(() => {
          row.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 150);
      }

      row.innerHTML = `
        <td>
          <img src="${resolveFotoUrl(alert.foto)}" class="table-thumbnail alert-thumb" alt="Evidencia" data-id="${alert.id}" onerror="this.onerror=null;this.src=getFotoPlaceholder()">
        </td>
        <td>
          <div style="font-weight: 600; font-size: 14px;">${alert.zona}</div>
          <div style="font-size: 12px; color: var(--color-text-secondary);">${alert.direccion}</div>
        </td>
        <td>
          <span style="font-size: 13px;">${alert.tipo}</span>
        </td>
        <td>
          <span class="badge ${stateObj.badgeClass}">${stateObj.label}</span>
          ${suspensionHtml}
        </td>
        <td style="font-size: 13px; color: var(--color-text-secondary);">
          ${formattedDate}
        </td>
        <td>
          ${operatorHtml}
        </td>
      `;

      tableBody.appendChild(row);
    });

    // Inicia el temporizador de cuenta regresiva de suspensión en las alertas activas
    initAlertsCountdownTicker();

    // Calcula y actualiza el texto de resumen de paginación (ej: "Mostrando 1-10 de 25 alertas")
    const page = typeof data.page !== 'undefined' ? data.page : currentPage;
    const perPageVal = typeof data.per_page !== 'undefined' ? data.per_page : perPage;
    const totalItems = typeof data.total !== 'undefined' ? data.total : (data.total_items || 0);
    const totalPages = typeof data.total_paginas !== 'undefined' ? data.total_paginas : (data.total_pages || 1);

    const startIdx = (page - 1) * perPageVal + 1;
    const endIdx = Math.min(startIdx + data.alertas.length - 1, totalItems);
    if (paginationInfo) {
      paginationInfo.textContent = `Mostrando ${startIdx}-${endIdx} de ${totalItems} alertas activas`;
    }

    // Dibuja los botones del paginador
    buildPagination(totalPages);

    // Inicializa los clicks para ampliar fotos
    initThumbModals();

  } catch (error) {
    console.error('Error al obtener alertas:', error);
    showTableError(error.message);
  }
}

/**
 * Temporizador en tiempo real (1s) para los contadores de suspensión de alertas activas
 */
function initAlertsCountdownTicker() {
  if (window._alertsCountdownInterval) {
    clearInterval(window._alertsCountdownInterval);
    window._alertsCountdownInterval = null;
  }

  function updateAlertTimers() {
    const boxes = document.querySelectorAll('.alerta-suspension-box');
    const now = Date.now();
    let hasActive = false;

    boxes.forEach(box => {
      const target = parseInt(box.getAttribute('data-target'), 10);
      if (!target) return;

      const diff = target - now;
      if (diff > 0) {
        hasActive = true;
        const totalSecs = Math.floor(diff / 1000);
        const mins = Math.floor(totalSecs / 60);
        const secs = totalSecs % 60;
        const digits = box.querySelector('.alerta-countdown-digits');
        if (digits) {
          digits.textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        }
      } else {
        // Expiró la suspensión de 30m sin nueva detección: transformar la fila en Resuelta
        box.innerHTML = `
          <span style="color: var(--color-success, #2ECC71); font-size: 11px; font-weight: 500;">
            ✓ Auto-resuelta (30m)
          </span>
        `;
        box.removeAttribute('data-target');

        const row = box.closest('tr');
        if (row) {
          const badge = row.querySelector('.badge');
          if (badge) {
            badge.className = 'badge badge-resuelta';
            badge.textContent = 'Resuelta';
          }
        }

        // Sincronizar en base de datos inmediatamente
        requestAPI('/api/alertas/verificar-expiradas', { method: 'POST' }).catch(() => {});
      }
    });

    if (!hasActive && boxes.length === 0) {
      if (window._alertsCountdownInterval) {
        clearInterval(window._alertsCountdownInterval);
        window._alertsCountdownInterval = null;
      }
    }
  }

  updateAlertTimers();
  window._alertsCountdownInterval = setInterval(updateAlertTimers, 1000);
}

/**
 * Renderiza 5 filas de esqueleto (Skeleton) animadas para indicar al usuario
 * que la información se está cargando desde el servidor.
 */
function renderTableSkeletons() {
  const tableBody = document.querySelector('#alerts-table tbody');
  if (!tableBody) return;

  tableBody.innerHTML = '';
  for (let i = 0; i < 5; i++) {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td><div class="skeleton skeleton-thumbnail"></div></td>
      <td>
        <div class="skeleton" style="height: 14px; width: 80px; margin-bottom: 6px;"></div>
        <div class="skeleton" style="height: 10px; width: 120px;"></div>
      </td>
      <td><div class="skeleton" style="height: 14px; width: 90px;"></div></td>
      <td><div class="skeleton skeleton-badge"></div></td>
      <td><div class="skeleton" style="height: 12px; width: 130px;"></div></td>
      <td>
        <div class="flex items-center gap: 8px;">
          <div class="skeleton skeleton-avatar"></div>
          <div class="skeleton" style="height: 12px; width: 70px;"></div>
        </div>
      </td>
    `;
    tableBody.appendChild(row);
  }
}

/**
 * Genera el formato de visualización del operador.
 * Si no está asignado y la alerta está pendiente, muestra un botón interactivo de "Asignar".
 * Si está asignado, muestra un avatar con las iniciales (ej: "MH" para Martín Hofstetter) y su nombre.
 */
function getOperatorDisplay(operatorName, alertId, alertStatus) {
  if (!operatorName || operatorName === 'Sin asignar' || operatorName.trim() === '') {
    return `
      <div class="operator-cell">
        <span class="operator-unassigned">Sin asignar</span>
      </div>
    `;
  }

  // Generación de iniciales del nombre
  const parts = operatorName.split(' ');
  let initials = '';
  if (parts.length > 0) {
    initials += parts[0][0];
    if (parts.length > 1) {
      initials += parts[1][0];
    }
  }
  initials = initials.toUpperCase();

  return `
    <div class="operator-cell">
      <div class="operator-avatar" title="${operatorName}">${initials}</div>
      <span class="operator-name">${operatorName}</span>
    </div>
  `;
}

/**
 * Genera el formato de visualización de las acciones de alerta en la columna Acciones.
 * Si la alerta está pendiente y sin asignar, muestra un botón interactivo de "Asignar".
 */
function getActionHtml(operatorName, alertId, alertStatus) {
  if ((!operatorName || operatorName === 'Sin asignar' || operatorName.trim() === '') && alertStatus === 'pendiente') {
    return `
      <button class="btn btn-secondary btn-asignar" data-id="${alertId}" style="padding: 4px 8px; font-size: 11px; cursor: pointer; border-radius: 4px; background-color: #4a5568; color: #fff; border: none; font-weight: 500;">Asignar</button>
    `;
  }
  return '';
}

/**
 * Crea dinámicamente los botones de control de páginas (Paginación).
 */
function buildPagination(totalPages) {
  const container = document.getElementById('pagination-controls');
  if (!container) return;

  container.innerHTML = '';

  // Oculta el paginador si toda la información entra en una sola página
  if (totalPages <= 1) return;

  // Botón: Anterior
  const prevBtn = document.createElement('button');
  prevBtn.className = `btn btn-secondary pagination-btn ${currentPage === 1 ? 'disabled' : ''}`;
  prevBtn.innerHTML = `&larr; Anterior`;
  prevBtn.disabled = currentPage === 1;
  prevBtn.addEventListener('click', () => {
    if (currentPage > 1) {
      currentPage--;
      loadAlertas();
    }
  });
  container.appendChild(prevBtn);

  // Páginas numeradas
  for (let i = 1; i <= totalPages; i++) {
    const pageBtn = document.createElement('button');
    pageBtn.className = `pagination-number-btn ${currentPage === i ? 'active' : ''}`;
    pageBtn.textContent = i;
    pageBtn.addEventListener('click', () => {
      if (currentPage !== i) {
        currentPage = i;
        loadAlertas();
      }
    });
    container.appendChild(pageBtn);
  }

  // Botón: Siguiente
  const nextBtn = document.createElement('button');
  nextBtn.className = `btn btn-secondary pagination-btn ${currentPage === totalPages ? 'disabled' : ''}`;
  nextBtn.innerHTML = `Siguiente &rarr;`;
  nextBtn.disabled = currentPage === totalPages;
  nextBtn.addEventListener('click', () => {
    if (currentPage < totalPages) {
      currentPage++;
      loadAlertas();
    }
  });
  container.appendChild(nextBtn);
}

/**
 * Helper para formatear fechas a representación humanizada (Argentina UTC-3).
 */
function formatDateTime(dateStr) {
  if (!dateStr) return '';
  let iso = String(dateStr).trim();
  if (!iso.endsWith('Z') && !/[+-]\d{2}:?\d{2}$/.test(iso)) {
    iso = iso.replace(' ', 'T') + 'Z';
  }
  const date = new Date(iso);
  if (isNaN(date.getTime())) return dateStr;

  const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
  const day = String(date.getDate()).padStart(2, '0');
  const month = months[date.getMonth()];
  const year = date.getFullYear();

  let hours = date.getHours();
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12;
  const strTime = `${String(hours).padStart(2, '0')}:${minutes} ${ampm}`;

  return `${day} ${month}, ${year} / ${strTime}`;
}

/**
 * Renderiza el estado de error en la tabla si falla la comunicación.
 */
function showTableError(msg) {
  const tableBody = document.querySelector('#alerts-table tbody');
  if (tableBody) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="7" class="text-center" style="padding: var(--spacing-xl); color: var(--color-danger);">
          <div style="font-size: 24px; margin-bottom: 10px;">⚠️</div>
          <div style="font-weight: 600; margin-bottom: 4px;">Error al cargar alertas</div>
          <div style="font-size: 13px; color: var(--color-text-secondary); margin-bottom: 12px;">${msg || 'No se pudo conectar al servidor.'}</div>
          <button onclick="loadAlertas()" class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;">Reintentar</button>
        </td>
      </tr>
    `;
  }
}

/**
 * Vincula clicks en miniaturas para abrir imágenes en modal gigante.
 */
function initThumbModals() {
  const thumbnails = document.querySelectorAll('.alert-thumb');
  const modalOverlay = document.getElementById('photo-modal');
  const modalImg = document.getElementById('modal-photo-img');
  const modalTitle = document.getElementById('modal-photo-title');
  const modalClose = document.getElementById('modal-photo-close');

  if (!modalOverlay || !modalImg || !modalClose) return;

  thumbnails.forEach(thumb => {
    thumb.addEventListener('click', () => {
      const alertId = thumb.getAttribute('data-id');
      modalImg.src = thumb.src;
      if (modalTitle) modalTitle.textContent = `Evidencia de Alerta ${alertId}`;
      modalOverlay.classList.add('active');
    });
  });

  const closeModal = () => {
    modalOverlay.classList.remove('active');
    modalImg.src = '';
  };

  modalClose.addEventListener('click', closeModal);
  modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) closeModal();
  });
}

/**
 * Inicializa y controla el modal para asignar un operador de recolección
 * a un incidente de basura.
 */
function initAsignarModal() {
  const modalAsignar = document.getElementById('asignar-operador-modal');
  const modalClose = document.getElementById('modal-asignar-close');
  const btnCancelar = document.getElementById('btn-cancelar-asignar');
  const btnConfirmar = document.getElementById('btn-confirmar-asignar');
  const selectOperador = document.getElementById('select-operador');
  const inputAlertaId = document.getElementById('asignar-alerta-id');

  if (!modalAsignar || !modalClose || !btnCancelar || !btnConfirmar || !selectOperador || !inputAlertaId) return;

  // Delegación de eventos en el cuerpo de la tabla para capturar clics en los botones dinámicos de "Asignar"
  const tableBody = document.querySelector('#alerts-table tbody');
  if (tableBody) {
    tableBody.addEventListener('click', async (e) => {
      if (e.target.classList.contains('btn-asignar')) {
        const alertaId = e.target.getAttribute('data-id');
        inputAlertaId.value = alertaId;
        
        selectOperador.innerHTML = '<option value="">Cargando operadores...</option>';
        updateConfirmButtonState();
        modalAsignar.classList.add('active');
        
        try {
          // Obtiene los operadores disponibles del backend
          const operadores = await requestAPI('/api/operadores');
          // Filtra únicamente operadores que se encuentren activos en el sistema
          const activos = operadores.filter(op => op.activo === 1 || op.activo === true);
          
          if (activos.length === 0) {
            selectOperador.innerHTML = '<option value="">No hay operadores activos</option>';
          } else {
            selectOperador.innerHTML = '<option value="">Selecciona un operador...</option>';
            activos.forEach(op => {
              const opt = document.createElement('option');
              opt.value = op.id;
              opt.textContent = `${op.nombre} ${op.apellido}`;
              selectOperador.appendChild(opt);
            });
          }
        } catch (err) {
          console.error("Error cargando operadores:", err);
          selectOperador.innerHTML = '<option value="">Error al cargar operadores</option>';
        } finally {
          updateConfirmButtonState();
        }
      }
    });
  }

  const updateConfirmButtonState = () => {
    btnConfirmar.disabled = !selectOperador.value;
  };

  selectOperador.addEventListener('change', updateConfirmButtonState);

  const closeModal = () => {
    modalAsignar.classList.remove('active');
    inputAlertaId.value = '';
    selectOperador.value = '';
    updateConfirmButtonState();
  };

  modalClose.addEventListener('click', closeModal);
  btnCancelar.addEventListener('click', closeModal);
  modalAsignar.addEventListener('click', (e) => {
    if (e.target === modalAsignar) closeModal();
  });

  // Envía la petición PATCH para registrar la asignación en la base de datos
  btnConfirmar.addEventListener('click', async () => {
    const alertaId = inputAlertaId.value;
    const operadorId = selectOperador.value;

    if (!alertaId || !operadorId) {
      alert("Por favor, selecciona un operador.");
      return;
    }

    btnConfirmar.disabled = true;
    btnConfirmar.textContent = 'Asignando...';

    try {
      const res = await requestAPI(`/api/alertas/${alertaId}/asignar`, {
        method: 'PATCH',
        body: JSON.stringify({ operador_id: parseInt(operadorId) })
      });

      if (res.ok) {
        closeModal();
        loadAlertas(); // Recarga la tabla con los datos actualizados
      } else {
        alert(res.mensaje || "Error al asignar el operador.");
      }
    } catch (err) {
      console.error("Error al asignar operador:", err);
      alert(err.message || "Error de conexión.");
    } finally {
      btnConfirmar.disabled = false;
      btnConfirmar.textContent = 'Confirmar asignación';
    }
  });
}
